local Blitbuffer = require("ffi/blitbuffer")
local Cache = require("cache")
local DataStorage = require("datastorage")
local Device = require("device")
local Event = require("ui/event")
local FrameContainer = require("ui/widget/container/framecontainer")
local IconWidget = require("ui/widget/iconwidget")
local ImageWidget = require("ui/widget/imagewidget")
local LineWidget = require("ui/widget/linewidget")
local LuaSettings = require("luasettings")
local ReaderFooter = require("apps/reader/modules/readerfooter")
local RenderImage = require("ui/renderimage")
local ScreenSaverWidget = require("ui/widget/screensaverwidget")
local Screen = Device.screen
local TextBoxWidget = require("ui/widget/textboxwidget")
local ToggleSwitch = require("ui/widget/toggleswitch")
local UIManager = require("ui/uimanager")
local VirtualKeyboard = require("ui/widget/virtualkeyboard")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local logger = require("logger")
local util = require("util")
local BD = require("ui/bidi")
local Geom = require("ui/geometry")
local UnderlineContainer = require("ui/widget/container/underlinecontainer")

local settings = LuaSettings:open(
    DataStorage:getSettingsDir() .. "/menucolor.lua"
)


local cfg = {
    enabled = settings:readSetting("enabled"),
}

if cfg.enabled == nil then
    cfg.enabled = false
end

local hooks_installed = false

local function saveSettings()
    settings:saveSetting("enabled", cfg.enabled)
    settings:flush()
end

local MENU_COLOR = Blitbuffer.COLOR_LIGHT_GRAY:getColorRGB32()

-- Decoy color: widgets that must not be recolored mark their
-- background with this before painting.
local EXCLUSION_COLOR = Blitbuffer.colorFromString("#DAAAAD")
local EXCLUSION_COLOR_RGB32 = EXCLUSION_COLOR:getColorRGB32()

local function is_excluded(color)
    return color and color:getColorRGB32() == EXCLUSION_COLOR_RGB32
end

local ImageCache = Cache:new {
    size = 8 * 1024 * 1024,
    avg_itemsize = 64 * 1024,
    enable_eviction_cb = false,
}

local function get_dpi_scale()
    local size_scale =
        math.min(Screen:getWidth(), Screen:getHeight()) * (1 / 600)
    local dpi_scale = Screen:scaleByDPI(1)

    return math.max(
        0,
        (math.log((size_scale + dpi_scale) / 2) / 0.69) ^ 2
    )
end

local DPI_SCALE = get_dpi_scale()

local function reloadIcons()
    ImageCache:clear()
    UIManager:broadcastEvent(Event:new("ChangeBackgroundColor"))
end

local function installHooks()
    if hooks_installed then
        return
    end

    hooks_installed = true

    ---------------------------------------------------------------
    -- FrameContainer: most menu/dialog backgrounds
    ---------------------------------------------------------------
    if not FrameContainer._menu_color_hooked then
        FrameContainer._menu_color_hooked = true

        local original_paintTo = FrameContainer.paintTo

        function FrameContainer:paintTo(bb, x, y)
            local original_background = self.background
            local original_color = self.color

            if cfg.enabled and original_background
                and not is_excluded(original_background)
                and original_background == Blitbuffer.COLOR_WHITE then
                self.background = MENU_COLOR
            elseif is_excluded(original_background) then
                self.background = self.original_background
            end

            if cfg.enabled and original_color == Blitbuffer.COLOR_WHITE then
                self.color = MENU_COLOR
            end

            original_paintTo(self, bb, x, y)

            self.background = original_background
            self.color = original_color
        end
    end

    ---------------------------------------------------------------
    -- UnderlineContainer
    ---------------------------------------------------------------
    if not UnderlineContainer._menu_color_hooked then
        UnderlineContainer._menu_color_hooked = true

        function UnderlineContainer:paintTo(bb, x, y)
            local container_size = self:getSize()

            if not self.dimen then
                self.dimen = Geom:new {
                    x = x,
                    y = y,
                    w = container_size.w,
                    h = container_size.h,
                }
            else
                self.dimen.x = x
                self.dimen.y = y
            end

            local line_width = self.line_width or self.dimen.w
            local line_x = x

            if BD.mirroredUILayout() then
                line_x = line_x + self.dimen.w - line_width
            end

            local content_size = self[1]:getSize()
            local p_y = y

            if self.vertical_align == "center" then
                p_y = math.floor(
                    (container_size.h - content_size.h) / 2
                ) + y
            elseif self.vertical_align == "bottom" then
                p_y = (container_size.h - content_size.h) + y
            end

            self[1]:paintTo(bb, x, p_y)

            local color = self.color

            if cfg.enabled and color == Blitbuffer.COLOR_WHITE then
                color = MENU_COLOR
            end

            if color ~= Blitbuffer.COLOR_WHITE then
                bb:paintRect(
                    line_x,
                    y + container_size.h - self.linesize,
                    line_width,
                    self.linesize,
                    color
                )
            end
        end
    end

    ---------------------------------------------------------------
    -- LineWidget
    ---------------------------------------------------------------
    if not LineWidget._menu_color_hooked then
        LineWidget._menu_color_hooked = true

        local original_paintTo = LineWidget.paintTo

        function LineWidget:paintTo(bb, x, y)
            local original_background = self.background

            if cfg.enabled and original_background
                and not is_excluded(original_background)
                and original_background == Blitbuffer.COLOR_WHITE then
                self.background = MENU_COLOR
            elseif is_excluded(original_background) then
                self.background = self.original_background
            end

            original_paintTo(self, bb, x, y)

            self.background = original_background
        end
    end

    ---------------------------------------------------------------
    -- TextBoxWidget
    ---------------------------------------------------------------
    if not TextBoxWidget._menu_color_hooked then
        TextBoxWidget._menu_color_hooked = true

        local original_renderText = TextBoxWidget._renderText

        function TextBoxWidget:_renderText(start_row_idx, end_row_idx)
            local original_bgcolor = self.bgcolor

            if cfg.enabled
                and not self.alpha
                and original_bgcolor == Blitbuffer.COLOR_WHITE
            then
                self.bgcolor = MENU_COLOR
            end

            original_renderText(
                self,
                start_row_idx,
                end_row_idx
            )

            self.bgcolor = original_bgcolor
        end
    end

    ---------------------------------------------------------------
    -- ImageWidget
    ---------------------------------------------------------------
    if not ImageWidget._menu_color_hooked then
        ImageWidget._menu_color_hooked = true

        function ImageWidget:_loadfile()
            local DocumentRegistry = require("document/documentregistry")

            if not DocumentRegistry:isImageFile(self.file) then
                error("Image file type not supported.")
            end

            local width, height

            if self.scale_factor == nil
                and self.stretch_limit_percentage == nil
            then
                width = self.width
                height = self.height
            end

            local hash =
                "image|"
                .. self.file
                .. "|"
                .. tostring(width)
                .. "|"
                .. tostring(height)
                .. "|"
                .. (self.alpha and "alpha" or "flat")
                .. "|"
                .. tostring(cfg.enabled)

            local scale_for_dpi_here = false

            if self.scale_for_dpi
                and DPI_SCALE ~= 1
                and not self.scale_factor
            then
                scale_for_dpi_here = true
                hash = hash .. "|d"
                self.already_scaled_for_dpi = true
            end

            local cached = ImageCache:check(hash)

            if cached then
                self._bb = cached.bb
                self._bb_disposable = false
                self._is_straight_alpha = cached.is_straight_alpha
                return
            end

            if util.getFileNameSuffix(self.file) == "svg" then
                local zoom

                if scale_for_dpi_here then
                    zoom = DPI_SCALE
                elseif self.scale_factor == 0 then
                    width = self.width
                    height = self.height
                end

                self._bb, self._is_straight_alpha =
                    RenderImage:renderSVGImageFile(
                        self.file,
                        width,
                        height,
                        zoom
                    )

                if not self._bb then
                    logger.warn("ImageWidget: Failed to render SVG image file:", self.file)
                    self._bb = RenderImage:renderCheckerboard(width, height, Screen.bb:getType())
                    self._is_straight_alpha = false
                end
            else
                self._bb = RenderImage:renderImageFile(self.file, false, width, height)

                if not self._bb then
                    logger.warn("ImageWidget: Failed to render image file:", self.file)
                    self._bb = RenderImage:renderCheckerboard(width, height, Screen.bb:getType())
                    self._is_straight_alpha = false
                end

                if scale_for_dpi_here then
                    local bb_w = self._bb:getWidth()
                    local bb_h = self._bb:getHeight()
                    self._bb = RenderImage:scaleBlitBuffer(
                        self._bb,
                        math.floor(bb_w * DPI_SCALE),
                        math.floor(bb_h * DPI_SCALE)
                    )
                end
            end

            if self.is_icon and not self.alpha then
                local bbtype = self._bb:getType()

                if bbtype == Blitbuffer.TYPE_BB8A or bbtype == Blitbuffer.TYPE_BBRGB32 then
                    local icon_bb = Blitbuffer.new(self._bb.w, self._bb.h, Screen.bb:getType())
                    local fill_color = cfg.enabled and MENU_COLOR or Blitbuffer.COLOR_WHITE

                    icon_bb:paintRectRGB32(0, 0, icon_bb.w, icon_bb.h, fill_color)

                    local mask_bb = Blitbuffer.new(self._bb.w, self._bb.h, Blitbuffer.TYPE_BB8)
                    mask_bb:fill(Blitbuffer.Color8(0xFF))

                    if self._is_straight_alpha then
                        mask_bb:alphablitFrom(self._bb, 0, 0, 0, 0, mask_bb.w, mask_bb.h)
                    else
                        mask_bb:pmulalphablitFrom(self._bb, 0, 0, 0, 0, mask_bb.w, mask_bb.h)
                    end

                    mask_bb:invertRect(0, 0, mask_bb.w, mask_bb.h)
                    icon_bb:colorblitFromRGB32(mask_bb, 0, 0, 0, 0, icon_bb.w, icon_bb.h, Blitbuffer.COLOR_BLACK)
                    mask_bb:free()

                    -- Keep the original for compatibility, but mark it as
                    -- owned by this widget so it is freed on :free().
                    self._unflattened = self._bb
                    self._unflattened_owned = true
                    self._bb = icon_bb
                    self._is_straight_alpha = nil
                end
            end

            if not self.file_do_cache then
                self._bb_disposable = true
            else
                self._bb_disposable = false

                cached = {
                    bb = self._bb,
                    is_straight_alpha = self._is_straight_alpha,
                }

                ImageCache:insert(
                    hash,
                    cached,
                    tonumber(cached.bb.stride) * cached.bb.h
                )
            end
        end
    end

    ---------------------------------------------------------------
    -- Ensure _unflattened bitmaps owned by the icon rewrite are freed.
    ---------------------------------------------------------------
    if not ImageWidget._menu_color_free_hooked then
        ImageWidget._menu_color_free_hooked = true

        local original_free = ImageWidget.free

        function ImageWidget:free()
            if self._unflattened_owned and self._unflattened then
                self._unflattened:free()
                self._unflattened = nil
                self._unflattened_owned = nil
            end
            return original_free(self)
        end
    end

    if not IconWidget._menu_color_hooked then
        IconWidget._menu_color_hooked = true

        local original_onChangeBackgroundColor =
            IconWidget.onChangeBackgroundColor

        function IconWidget:onChangeBackgroundColor()
            self:free()
            self:init()

            if original_onChangeBackgroundColor then
                original_onChangeBackgroundColor(self)
            end
        end
    end

    ---------------------------------------------------------------
    -- Opt-outs
    ---------------------------------------------------------------
    if not ScreenSaverWidget._menu_color_hooked then
        ScreenSaverWidget._menu_color_hooked = true

        local original_init = ScreenSaverWidget.init

        function ScreenSaverWidget:init()
            original_init(self)
            if self.background then
                self[1].original_background = self[1].background
                self[1].background = EXCLUSION_COLOR
            end
        end
    end

    if not ReaderFooter._menu_color_hooked then
        ReaderFooter._menu_color_hooked = true

        local original_updateFooterContainer =
            ReaderFooter.updateFooterContainer

        function ReaderFooter:updateFooterContainer()
            original_updateFooterContainer(self)
            self.footer_content.original_background = self.footer_content.background
            self.footer_content.background = EXCLUSION_COLOR
        end
    end

    if not ToggleSwitch._menu_color_hooked then
        ToggleSwitch._menu_color_hooked = true

        local original_update = ToggleSwitch.update

        function ToggleSwitch:update()
            original_update(self)

            local pos = self.position
            for i = 1, #self.toggle_content do
                local row = self.toggle_content[i]
                for j = 1, #row do
                    local cell = row[j]
                    if pos == (i - 1) * self.n_pos + j then
                        cell.original_background = cell.background
                        cell.background = EXCLUSION_COLOR
                    end
                end
            end
        end
    end

    if not VirtualKeyboard._menu_color_hooked then
        VirtualKeyboard._menu_color_hooked = true

        local original_addKeys = VirtualKeyboard.addKeys

        function VirtualKeyboard:addKeys()
            original_addKeys(self)
            local keyboard_frame = self[1] and self[1][1]
            if keyboard_frame then
                keyboard_frame.original_background = keyboard_frame.background
                keyboard_frame.background = EXCLUSION_COLOR
            end
        end
    end
end

local MenuColor = WidgetContainer:extend {
    name = "menucolor",
    is_doc_only = false,
}

function MenuColor.init()
    if cfg.enabled then
        installHooks()
    end
end

function MenuColor.isEnabled()
    return cfg.enabled
end

function MenuColor.toggle()
    cfg.enabled = not cfg.enabled

    saveSettings()

    if cfg.enabled then
        installHooks()
    end

    reloadIcons()

    UIManager:setDirty("all", "full")
end

function MenuColor.disable()
    if not cfg.enabled then
        return
    end

    cfg.enabled = false
    saveSettings()

    UIManager:nextTick(function()
        reloadIcons()

        local FileManager = package.loaded["apps/filemanager/filemanager"]

        if FileManager and FileManager.instance then
            UIManager:sendEvent(
                Event:new("ChangeBackgroundColor"),
                FileManager.instance
            )
        end

        UIManager:setDirty("all", "full")

        UIManager:scheduleIn(0.4, function()
            reloadIcons()
            UIManager:setDirty("all", "full")
        end)
    end)
end
return MenuColor