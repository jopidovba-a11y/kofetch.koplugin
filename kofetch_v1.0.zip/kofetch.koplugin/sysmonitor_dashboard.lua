local Blitbuffer = require("ffi/blitbuffer")
local BottomBar = require("bottombar")
local Cards = require("cards")
local CornerTexts = require("cornertexts")
local CpuInfo = require("cpuinfo")
local Device = require("device")
local EntryActions = require("entryactions")
local FileExplorer = require("fileexplorer")
local FileManager = require("apps/filemanager/filemanager")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local GestureRange = require("ui/gesturerange")
local InfoMessage = require("ui/widget/infomessage")
local InputContainer = require("ui/widget/container/inputcontainer")
local OverlapGroup = require("ui/widget/overlapgroup")
local SystemInfo = require("systeminfo")
local TerminalBar = require("terminalbar")
local UIManager = require("ui/uimanager")
local VerticalGroup = require("ui/widget/verticalgroup")
local _ = require("gettext")

local Dashboard = InputContainer:extend{}

local live_dashboard = nil

-- Setting that enables opening the last book by tapping the main ASCII
-- art. Enabled by default (nil counts as true).
local TAP_ART_SETTING_KEY = "sysmonitor_tap_art_opens_last_book"

-- Last folder visited in the explorer.
local last_explorer_path = nil

-- Share of the usable height given to card 1.
local CARD1_SHARE = 0.50

-- Only taps and holds inside the top band can reach the hidden FileChooser.
local TOP_PASS_RATIO = 0.08

local BLOCKED_OUTSIDE_TOP = {
    tap = true,
    double_tap = true,
    hold = true,
    hold_pan = true,
    hold_release = true,
}

-- Watching G_reader_settings:saveSetting is the most reliable place to
-- detect a "show hidden" change, because the FileManager menu may toggle
-- it through a saved setting, a flip helper or an event depending on the
-- KOReader version. Installed once, never removed: harmless when no
-- dashboard is open.
local function installShowHiddenHook()
    if G_reader_settings._kofetch_orig_saveSetting then
        return
    end

    local original = G_reader_settings.saveSetting

    G_reader_settings._kofetch_orig_saveSetting = original

    G_reader_settings.saveSetting = function(this, key, value)
        local result = original(this, key, value)

        if key == "show_hidden" and live_dashboard then
            local dashboard = live_dashboard

            -- Defer one tick so the current menu callback finishes and
            -- the setting is fully saved before the explorer re-reads it.
            UIManager:nextTick(function()
                if dashboard == live_dashboard then
                    dashboard:reloadExplorer()
                end
            end)
        end

        return result
    end
end

-- Keep FileManager actions working while blocking its hidden FileChooser.
-- The original handleEvent is stashed on the FileChooser itself so the
-- wrapper can be installed and removed idempotently, even if lock runs
-- more than once without an intervening unlock.
local function lockFileManager(fm)
    fm.is_always_active = true

    local fc = fm.file_chooser

    if fc and not fc._kofetch_orig_handleEvent then
        fc._kofetch_orig_handleEvent = fc.handleEvent

        fc.handleEvent = function(this, event)
            if event and event.handler == "onGesture"
                and live_dashboard
                and UIManager:isWidgetShown(live_dashboard) then
                return false
            end

            return fc._kofetch_orig_handleEvent(this, event)
        end
    end
end

local function unlockFileManager(fm)
    fm.is_always_active = nil

    local fc = fm.file_chooser

    if fc and fc._kofetch_orig_handleEvent then
        fc.handleEvent = fc._kofetch_orig_handleEvent
        fc._kofetch_orig_handleEvent = nil
    end
end

local function openBook(dashboard, path)
    local DocumentRegistry = require("document/documentregistry")

    local ok, supported = pcall(function()
        return DocumentRegistry:hasProvider(path)
    end)

    if ok and not supported then
        UIManager:show(InfoMessage:new{
            text = _("Unsupported file type"),
            timeout = 2,
        })

        return
    end

    local ReaderUI = require("apps/reader/readerui")

    UIManager:close(dashboard)

    if FileManager.instance then
        FileManager.instance:onClose()
    end

    ReaderUI:showReader(path)
end

-- Calculate the initial body heights for the three cards.
local function computeCardBodyHeights(screen_h, bottom_bar_h, bars_h, explorer_min_h)
    local available_h = screen_h - bottom_bar_h - bars_h

    local old_bottom_bar_h = Cards.sc(20) + (Cards.sc(5) * 2)
    local reference_h = screen_h - old_bottom_bar_h - bars_h
    local reference_card1_h = math.floor(reference_h * CARD1_SHARE)

    local equal_h = math.max(
        math.floor((reference_h - reference_card1_h) / 2),
        explorer_min_h
    )

    local card1_target_h = available_h - (equal_h * 2)

    return
        math.max(1, card1_target_h - (Cards.sc(15) * 2)),
        math.max(1, equal_h),
        math.max(1, equal_h)
end

function Dashboard:onGesture(ges)
    -- Handle dashboard zones first.
    if InputContainer.onGesture(self, ges) then
        return true
    end

    -- Let FileManager zones such as the gestures plugin and top menu work.
    local fm = FileManager.instance

    if fm and InputContainer.onGesture(fm, ges) then
        return true
    end

    -- Prevent taps and holds from reaching the hidden FileChooser.
    if BLOCKED_OUTSIDE_TOP[ges.ges] and ges.pos then
        local top_limit = Device.screen:getHeight() * TOP_PASS_RATIO

        if ges.pos.y >= top_limit then
            return true
        end
    end

    -- Keep swipes and pans available to FileManager.
    return false
end

function Dashboard:init()
    local screen_size = Device.screen:getSize()
    self.dimen = screen_size

    self._fm = FileManager.instance

    if self._fm then
        lockFileManager(self._fm)
    end

    installShowHiddenHook()

    self.ges_events = {}

    local bar_h = Cards.sc(15)
    local card_w = screen_size.w

    local bottom_bar = BottomBar.build(screen_size)
    local bottom_bar_h = bottom_bar:getSize().h

    local home_dir = G_reader_settings:readSetting("home_dir") or "/mnt/onboard"
    local start_path = last_explorer_path or home_dir

    local path_bar, path_text, page_text =
        TerminalBar.build(home_dir, card_w, bar_h, "")

    local cpu_bar = TerminalBar.build("cpu@koreader~#", card_w, bar_h)

    local function onPathChange(new_path)
        last_explorer_path = new_path
        path_text:setText(new_path)

        if self.path_bar_y and UIManager:isWidgetShown(self) then
            UIManager:setDirty(self, "ui", Geom:new{
                x = 0,
                y = self.path_bar_y,
                w = card_w,
                h = bar_h,
            })
        end
    end

    local function onPageChange(page, total_pages)
        page_text:setText(page .. "/" .. total_pages)

        if self.path_bar_y and UIManager:isWidgetShown(self) then
            UIManager:setDirty(self, "ui", Geom:new{
                x = 0,
                y = self.path_bar_y,
                w = card_w,
                h = bar_h,
            })
        end
    end

    local card1_body_h, card2_body_h, card3_body_h =
        computeCardBodyHeights(
            screen_size.h,
            bottom_bar_h,
            bar_h * 2,
            FileExplorer.measureMinHeight(card_w)
        )

    local side_font_px = Cards.sc(7)
    local art_size = nil

    -- card2 and card3 depend only on their own body heights, so they can
    -- be rebuilt without touching card1 when the rounding pass adjusts
    -- the layout.
    local function buildCard2()
        return FileExplorer.build(
            start_path,
            card_w,
            card2_body_h,
            function(path)
                openBook(self, path)
            end,
            onPathChange,
            onPageChange
        )
    end

    local function buildCard3()
        return CpuInfo.build(card_w, card3_body_h)
    end

    local card1, card2, card3

    -- Build card1 (ASCII art + corner blocks) only once.
    do
        local built_card1, art_widget =
            Cards.buildLibraryCard(card_w, card1_body_h)
        art_size = art_widget:getSize()
        side_font_px = CornerTexts.pickFontPx(
            card_w,
            built_card1:getSize().h,
            art_widget:getSize().w
        )

        card1 = CornerTexts.buildSystemBlock(
            built_card1,
            card_w,
            side_font_px,
            SystemInfo.getSystemDetails(screen_size)
        )
    end

    card2 = buildCard2()
    card3 = buildCard3()

    local function usedHeight()
        return card1:getSize().h
            + bar_h
            + card2:getSize().h
            + bar_h
            + card3:getSize().h
            + bottom_bar_h
    end

    -- Absorb rounding leftovers in cards 2 and 3. card1 is left untouched.
    for attempt = 1, 2 do
        local delta = screen_size.h - usedHeight()

        if delta == 0 then
            break
        end

        local adjust = math.floor(delta / 2)

        card2_body_h = math.max(1, card2_body_h + adjust)
        card3_body_h = math.max(1, card3_body_h + (delta - adjust))

        card2 = buildCard2()
        card3 = buildCard3()
    end

    local card2_y = card1:getSize().h + bar_h

    self.path_bar_y = card1:getSize().h
    self.card2 = card2
    self.card2_y = card2_y
    self.card3 = card3
    self.card3_y = card2_y + card2:getSize().h + bar_h

    CpuInfo.on_refresh = function()
        if not UIManager:isWidgetShown(self) then
            return
        end

        UIManager:setDirty(self, "ui", Geom:new{
            x = 0,
            y = self.card3_y,
            w = self.card3:getSize().w,
            h = self.card3:getSize().h,
        })
    end

    self.ges_events.Card2 = {
        GestureRange:new{
            ges = "tap",
            range = Geom:new{
                x = 0,
                y = card2_y,
                w = screen_size.w,
                h = card2:getSize().h,
            },
        },
    }

    self.ges_events.Card2Hold = {
        GestureRange:new{
            ges = "hold",
            range = Geom:new{
                x = 0,
                y = card2_y,
                w = screen_size.w,
                h = card2:getSize().h,
            },
        },
    }

    local dashboard_content = VerticalGroup:new{
        align = "left",

        card1,
        path_bar,
        card2,
        cpu_bar,
        card3,
        bottom_bar,
    }

    local memory_overlay = CornerTexts.buildMemoryBlock(
        screen_size.w,
        side_font_px,
        SystemInfo.getMemoryInfo(home_dir)
    )

        -- Tapping the main ASCII art (centered in card 1) opens the last book.
    -- The gesture is always registered; the setting is checked on tap.
    self.ges_events.Card1Art = {
        GestureRange:new{
            ges = "tap",
            range = Geom:new{
                x = math.floor((card_w - art_size.w) / 2),
                y = math.floor((card1:getSize().h - art_size.h) / 2),
                w = art_size.w,
                h = art_size.h,
            },
        },
    }

    local overlay_group = OverlapGroup:new{
        dimen = Geom:new{
            x = 0,
            y = 0,
            w = screen_size.w,
            h = screen_size.h,
        },

        dashboard_content,
        memory_overlay,
    }

    self[1] = FrameContainer:new{
        background = Blitbuffer.COLOR_WHITE,
        bordersize = 0,
        padding = 0,
        width = screen_size.w,
        height = screen_size.h,

        overlay_group,
    }
end

function Dashboard:onTapClose()
    self.card2 = nil

    UIManager:close(self)

    return true
end

function Dashboard:onCard1Art()
    if not G_reader_settings:nilOrTrue(TAP_ART_SETTING_KEY) then
        return false
    end

    local last_book = SystemInfo.getLastBook()

    if last_book then
        openBook(self, last_book)
    end

    return true
end

function Dashboard:onCard2(arg, ges)
    if not self.card2 or not ges then
        return true
    end

    local changed = self.card2:onTapAt(
        ges.pos.x,
        ges.pos.y - self.card2_y
    )

    if UIManager:isWidgetShown(self) then
        if changed == "page" then
            UIManager:setDirty(self, "ui", Geom:new{
                x = 0,
                y = self.card2_y + self.card2.page_refresh_y,
                w = self.card2:getSize().w,
                h = self.card2.page_refresh_h,
            })
        elseif changed == "full" then
            UIManager:setDirty(self, "ui", Geom:new{
                x = 0,
                y = self.card2_y,
                w = self.card2:getSize().w,
                h = self.card2:getSize().h,
            })
        end
    end

    return true
end

function Dashboard:reloadExplorer()
    if not self.card2 then
        return
    end

    self.card2:reload()

    if UIManager:isWidgetShown(self) then
        UIManager:setDirty(self, "ui", Geom:new{
            x = 0,
            y = self.card2_y,
            w = self.card2:getSize().w,
            h = self.card2:getSize().h,
        })
    end
end

function Dashboard:onCard2Hold(arg, ges)
    if not self.card2 or not ges then
        return true
    end

    local entry = self.card2:entryAt(ges.pos.y - self.card2_y)

    if entry and not entry.shortcut then
        EntryActions.show(entry, function()
            self:reloadExplorer()
        end)
    end

    return true
end

function Dashboard:onCloseWidget()
    self.card2 = nil
    if self._fm then
        unlockFileManager(self._fm)
        self._fm = nil
    end

        if live_dashboard == self then
        live_dashboard = nil
        CpuInfo.on_refresh = nil
    end
end

local M = {}
M.TAP_ART_SETTING_KEY = TAP_ART_SETTING_KEY
function M.isShown()
    return live_dashboard ~= nil and UIManager:isWidgetShown(live_dashboard)
end

function M.show()
    if M.isShown() then
        return
    end

    -- Show initialization errors on screen instead of crashing.
    local ok, result = pcall(function()
        return Dashboard:new{}
    end)

    if not ok then
        local fm = FileManager.instance

        if fm then
            unlockFileManager(fm)
        end

        UIManager:show(InfoMessage:new{
            text = "Dashboard error:\n" .. tostring(result),
            timeout = 20,
        })

        return
    end

    live_dashboard = result

    UIManager:show(live_dashboard)
end

function M.close()
    if M.isShown() then
        UIManager:close(live_dashboard)
    end
end

function M.resetExplorerPath()
    last_explorer_path = nil
end

return M