local Blitbuffer = require("ffi/blitbuffer")
local Cards = require("cards")
local Font = require("ui/font")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local LeftContainer = require("ui/widget/container/leftcontainer")
local RightContainer = require("ui/widget/container/rightcontainer")
local TextWidget = require("ui/widget/textwidget")
local WidgetContainer = require("ui/widget/container/widgetcontainer")

local TerminalBar = {}


function TerminalBar.build(text, width, height, right_text)
    local pad = Cards.sc(4)
    local inner_w = width - (pad * 2)
    local inner_h = height - (pad * 2)

    local face = Font:getFace("DroidSansMono", Cards.sc(8))

    local text_widget = TextWidget:new{
        text = text,
        face = face,
        fgcolor = Blitbuffer.COLOR_LIGHT_GRAY,
        max_width = inner_w,
    }

    local right_widget = TextWidget:new{
        text = right_text or "",
        face = face,
        fgcolor = Blitbuffer.COLOR_LIGHT_GRAY,
        max_width = inner_w,
    }

    
    local left_w = math.floor(inner_w * 0.6)
    local right_w = inner_w - left_w

    local bar = WidgetContainer:new{
        dimen = { x = 0, y = 0, w = width, h = height },

        FrameContainer:new{
            background = Blitbuffer.Color8(80),
            bordersize = 0,
            padding = pad,
            width = width,
            height = height,

            HorizontalGroup:new{
                align = "center",

                LeftContainer:new{
                    dimen = Geom:new{ w = left_w, h = inner_h },
                    text_widget,
                },

                RightContainer:new{
                    dimen = Geom:new{ w = right_w, h = inner_h },
                    right_widget,
                },
            },
        },
    }

    return bar, text_widget, right_widget
end

return TerminalBar