local Blitbuffer = require("ffi/blitbuffer")
local Cards = require("cards")
local DocumentRegistry = require("document/documentregistry")
local Font = require("ui/font")
local FrameContainer = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan = require("ui/widget/horizontalspan")
local InputContainer = require("ui/widget/container/inputcontainer")
local OverlapGroup = require("ui/widget/overlapgroup")
local Paint = require("paint")
local TextWidget = require("ui/widget/textwidget")
local VerticalGroup = require("ui/widget/verticalgroup")
local VerticalSpan = require("ui/widget/verticalspan")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local lfs = require("libs/libkoreader-lfs")

local TEXT_COLOR = Blitbuffer.Color8(60)

local ARROW_SIZE = 10

local ARROW_EDGE_MARGIN = 6
local ARROW_TEXT_GAP = 6

local ARROW_TAP_TEXT_GAP = 3

-- Row font sizes to try, largest first (scaled with Cards.sc).
local ROW_SIZES = { 14, 13, 12, 11, 10, 9, 8 }

-- Visible books per page, not counting the fixed top row. On big screens
-- the font grows past ROW_SIZES until no more than MAX rows fit.
local MIN_PREFERRED_ROWS = 5
local MAX_PREFERRED_ROWS = 7

-- Hard limit for that growth (scaled units).
local MAX_GROWN_SIZE = 40

local Explorer = {}

local function lineHeight(text, face, max_width)
    return TextWidget:new{
        text = text,
        face = face,
        max_width = max_width,
    }:getSize().h
end

local function entryLabel(entry)
    return (entry.is_dir and "[D] " or "[F] ") .. entry.name
end


-- Cached: the arrow glyph width and margins never change at runtime,
-- so measuring once avoids rebuilding a TextWidget on every refresh.
local cached_side_pad = nil

local function computeSidePad()
    if cached_side_pad then
        return cached_side_pad
    end

    local arrow_face = Font:getFace("cfont", Cards.sc(ARROW_SIZE))
    local arrow_probe = TextWidget:new{ text = "◀", face = arrow_face }
    local arrow_w = arrow_probe:getSize().w

    cached_side_pad = Cards.sc(ARROW_EDGE_MARGIN)
        + arrow_w
        + Cards.sc(ARROW_TEXT_GAP)

    return cached_side_pad
end

-- Folders plus the files KOReader can open as books.
function Explorer.getEntries(path)
    local entries = {}

    local show_hidden = G_reader_settings:isTrue("show_hidden")

    local ok, iterator, dir_obj = pcall(lfs.dir, path)

    if not ok then
        return entries
    end

    -- A single pcall around the loop protects against unexpected lfs
    -- failures, without wrapping every attributes() call (which is the
    -- hot path on folders with many entries).
    pcall(function()
        for name in iterator, dir_obj do
            local skip = name == "."
                or name == ".."
                or (not show_hidden and name:sub(1, 1) == ".")

            if not skip then
                local full_path = path .. "/" .. name
                local attr = lfs.attributes(full_path)

                if attr then
                    local is_dir = attr.mode == "directory"
                    local is_sdr = is_dir
                        and name:lower():match("%.sdr$") ~= nil

                    if not is_sdr
                        and (is_dir or DocumentRegistry:hasProvider(full_path)) then
                        entries[#entries + 1] = {
                            name = name,
                            is_dir = is_dir,
                            path = full_path,
                        }
                    end
                end
            end
        end
    end)

    table.sort(entries, function(a, b)
        if a.is_dir ~= b.is_dir then
            return a.is_dir
        end

        return a.name:lower() < b.name:lower()
    end)

    return entries
end

function Explorer.getPage(entries, page, per_page)
    local total = #entries

    if total == 0 then
        return {}, 1
    end

    local total_pages = math.ceil(total / per_page)
    page = math.max(1, math.min(page, total_pages))

    local first = ((page - 1) * per_page) + 1
    local last = math.min(first + per_page - 1, total)

    local result = {}

    for i = first, last do
        table.insert(result, entries[i])
    end

    return result, total_pages
end


local function buildTopRow(path, home_path)
    if path ~= "/" then
        local parent = path:match("^(.*)/[^/]+$")

        if parent then
            if parent == "" then
                parent = "/"
            end

            return {
                text = "[D] ..",
                entry = { name = "..", is_dir = true, path = parent, shortcut = true },
            }
        end
    end

    if home_path and home_path ~= path then
        return {
            text = "[D] ~ Home",
            entry = { name = "Home", is_dir = true, path = home_path, shortcut = true },
        }
    end

    return nil
end

local function pickRowFont(entries_h, row_spacing, reserved_rows, text_w)
    local function measure(size)
        local face = Font:getFace("DroidSansMono", Cards.sc(size))
        local height = lineHeight("[D] Ag", face, text_w)
        local rows = math.floor(entries_h / (height + row_spacing))
            - reserved_rows

        return face, height, rows
    end

    local size = ROW_SIZES[1]
    local face, height, rows = measure(size)

    if rows > MAX_PREFERRED_ROWS then
        while rows > MAX_PREFERRED_ROWS and size < MAX_GROWN_SIZE do
            size = size + 1
            face, height, rows = measure(size)
        end

        return face, height, size
    end

    local best_face, best_h, best_size, best_rows

    for _, candidate in ipairs(ROW_SIZES) do
        local f, h, r = measure(candidate)

        if r >= MIN_PREFERRED_ROWS then
            return f, h, candidate
        end

        if not best_rows or r > best_rows then
            best_face, best_h, best_size, best_rows = f, h, candidate, r
        end
    end

    return best_face, best_h, best_size
end

local ExplorerWidget = InputContainer:extend{}

function ExplorerWidget:init()
    self.path = self.initial_path
    self.home_path = G_reader_settings:readSetting("home_dir") or self.initial_path
    self.page = 1

    self:refresh()
end

function ExplorerWidget:refresh()
    self.entries = Explorer.getEntries(self.path)

    local pad = Cards.sc(15)
    local row_spacing = Cards.sc(2)

    local width = self.width

    local arrow_face = Font:getFace("cfont", Cards.sc(ARROW_SIZE))

    local left_arrow = TextWidget:new{
        text = "◀",
        face = arrow_face,
        fgcolor = TEXT_COLOR,
    }

    local right_arrow = TextWidget:new{
        text = "▶",
        face = arrow_face,
        fgcolor = TEXT_COLOR,
    }

    local left_size = left_arrow:getSize()
    local right_size = right_arrow:getSize()

    local side_pad = computeSidePad()
    local text_w = width - (pad * 2) - (side_pad * 2)

    local top_row = buildTopRow(self.path, self.home_path)
    self.has_parent_row = top_row ~= nil

    local reserved_rows = top_row and 1 or 0

    local available_h = self.height - (pad * 2)
    local entries_h = available_h

    local row_face, row_h =
        pickRowFont(entries_h, row_spacing, reserved_rows, text_w)

    local possible_rows = math.floor(entries_h / (row_h + row_spacing))
    self.per_page = math.max(
        1,
        math.min(possible_rows - reserved_rows, MAX_PREFERRED_ROWS)
    )

    local page_entries, total_pages =
        Explorer.getPage(self.entries, self.page, self.per_page)

    self.total_pages = total_pages
    self.page = math.min(self.page, total_pages)

    local children = {}
    local y = pad

    self.touch_zones = {}
    self.row_text_widgets = {}

    local function addRow(text, entry, bold)
        local text_widget = TextWidget:new{
            text = text,
            face = row_face,
            max_width = text_w,
            fgcolor = TEXT_COLOR,
            bold = bold or false,
        }

        table.insert(children, FrameContainer:new{
            background = Blitbuffer.COLOR_LIGHT_GRAY,
            bordersize = 0,
            padding = 0,
            width = text_w,
            height = row_h,
            text_widget,
        })

        table.insert(children, VerticalSpan:new{ width = row_spacing })

        table.insert(self.row_text_widgets, text_widget)

        table.insert(self.touch_zones, {
            y = y,
            h = row_h + row_spacing,
            entry = entry,
        })

        y = y + row_h + row_spacing
    end

    if top_row then
        addRow(top_row.text, top_row.entry, true)
    end

    for i = 1, self.per_page do
        local entry = page_entries[i]
        addRow(entry and entryLabel(entry) or "", entry)
    end

    self.page_refresh_y = pad
    self.page_refresh_h = math.max(1, y - pad)

    local content = FrameContainer:new{
        background = Blitbuffer.COLOR_LIGHT_GRAY,
        bordersize = 0,
        padding = 0,
        width = width - (pad * 2),
        height = available_h,

        HorizontalGroup:new{
            align = "top",

            HorizontalSpan:new{ width = side_pad },

            VerticalGroup:new{
                align = "left",
                unpack(children),
            },

            HorizontalSpan:new{ width = side_pad },
        },
    }

    local outer = FrameContainer:new{
        background = Blitbuffer.COLOR_LIGHT_GRAY,
        bordersize = 0,
        padding = pad,
        width = width,
        height = self.height,

        content,
    }

    local fixed_outer = WidgetContainer:new{
        dimen = { x = 0, y = 0, w = width, h = self.height },

        outer,
    }


    local arrow_space = pad + side_pad
    local arrow_left_x = math.floor(
        (arrow_space - left_size.w) / 2
    )
    local arrow_right_x = width - arrow_left_x - right_size.w

    local arrow_h = math.max(left_size.h, right_size.h)
    local arrow_y = math.floor((self.height - arrow_h) / 2)

    local left_arrow_pos = WidgetContainer:new{
        dimen = {
            x = arrow_left_x,
            y = arrow_y,
            w = left_size.w,
            h = arrow_h,
        },

        left_arrow,
    }

    local right_arrow_pos = WidgetContainer:new{
        dimen = {
            x = arrow_right_x,
            y = arrow_y,
            w = right_size.w,
            h = arrow_h,
        },

        right_arrow,
    }


    self.arrow_tap_edge_w = arrow_space - Cards.sc(ARROW_TAP_TEXT_GAP)

    if self.on_page_change then
        self.on_page_change(self.page, self.total_pages)
    end

    if self.on_path_change then
        self.on_path_change(self.path)
    end

    self[1] = OverlapGroup:new{
        dimen = { x = 0, y = 0, w = width, h = self.height },

        Paint.addBorder(
            fixed_outer,
            Blitbuffer.COLOR_DARK_GRAY,
            Cards.sc(4),
            Cards.sc(4)
        ),

        left_arrow_pos,
        right_arrow_pos,
    }
end

function ExplorerWidget:updatePage(new_page)
    new_page = math.max(1, math.min(new_page, self.total_pages))

    if new_page == self.page then
        return false
    end

    self.page = new_page

    local page_entries =
        Explorer.getPage(self.entries, self.page, self.per_page)

    if self.on_page_change then
        self.on_page_change(self.page, self.total_pages)
    end

    local first_row = self.has_parent_row and 2 or 1

    for i = 1, self.per_page do
        local index = first_row + i - 1
        local entry = page_entries[i]

        self.row_text_widgets[index]:setText(entry and entryLabel(entry) or "")
        self.touch_zones[index].entry = entry
    end

    return true
end

function ExplorerWidget:onPreviousPage()
    if self.page > 1 and self:updatePage(self.page - 1) then
        return "page"
    end

    return false
end

function ExplorerWidget:onNextPage()
    if self.page < self.total_pages and self:updatePage(self.page + 1) then
        return "page"
    end

    return false
end

function ExplorerWidget:onEntry(entry)
    if not entry then
        return false
    end

    if entry.is_dir then
        self.path = entry.path
        self.page = 1

        self:refresh()

        return "full"
    end

    if self.on_open_file then
        self.on_open_file(entry.path)
    end

    return false
end

function ExplorerWidget:entryAt(y)
    for _, zone in ipairs(self.touch_zones) do
        if y >= zone.y and y < zone.y + zone.h then
            return zone.entry
        end
    end

    return nil
end


function ExplorerWidget:reload()
    self.home_path = G_reader_settings:readSetting("home_dir") or self.home_path
    self:refresh()
end

function ExplorerWidget:onTapAt(x, y)

    if x < self.arrow_tap_edge_w then
        return self:onPreviousPage()
    end

    if x > self.width - self.arrow_tap_edge_w then
        return self:onNextPage()
    end

    return self:onEntry(self:entryAt(y))
end

function Explorer.measureMinHeight(width)
    local pad = Cards.sc(15)
    local row_spacing = Cards.sc(2)
    local side_pad = computeSidePad()
    local text_w = width - (pad * 2) - (side_pad * 2)

    local row_h = lineHeight(
        "[D] Ag",
        Font:getFace("cfont", Cards.sc(10)),
        text_w
    )

    return (pad * 2) + (row_h + row_spacing) * 2
end

function Explorer.build(
    path,
    width,
    height,
    on_open_file,
    on_path_change,
    on_page_change
)
    return ExplorerWidget:new{
        initial_path = path,
        width = width,
        height = height,
        on_open_file = on_open_file,
        on_path_change = on_path_change,
        on_page_change = on_page_change,
    }
end

return Explorer