local CpuInfo = require("cpuinfo")
local Dashboard = require("sysmonitor_dashboard")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local MenuColor = require("menucolor")
local UIManager = require("ui/uimanager")
local _ = require("gettext")

local Menu = {}

local AUTOSTART_SETTING_KEY = "sysmonitor_autostart"

local FLASH_UI_SETTING_KEY = "flash_ui"

local function buildEnableItem(autostart_key)
    return {
        text = _("ENABLE_KOFETCH"),

        checked_func = function()
            return G_reader_settings:isTrue(autostart_key)
        end,

        callback = function(touchmenu_instance)
            local was_enabled = G_reader_settings:isTrue(autostart_key)

            G_reader_settings:saveSetting(autostart_key, not was_enabled)

            if touchmenu_instance and touchmenu_instance.closeMenu then
                touchmenu_instance:closeMenu()
            end

            UIManager:nextTick(function()
                if was_enabled then
                    Dashboard.close()
                    CpuInfo.stop()
                    MenuColor.disable()
                else
                    Dashboard.show()
                end
            end)
        end,
    }
end

local function buildMenuColorItem()
    return {
        text = _("LIGHT_GRAY_MENUS"),

        
        enabled_func = function()
            return G_reader_settings:isTrue(AUTOSTART_SETTING_KEY)
        end,

        checked_func = function()
            return MenuColor.isEnabled()
        end,

        callback = function()
            MenuColor.toggle()

            if MenuColor.isEnabled() then
                G_reader_settings:saveSetting(FLASH_UI_SETTING_KEY, false)
            end
        end,
    }
end

local function buildTapArtItem()
    return {
        text = _("TAP_ART_OPENS_LAST_BOOK"),

        checked_func = function()
            return G_reader_settings:nilOrTrue(Dashboard.TAP_ART_SETTING_KEY)
        end,

        callback = function()
            G_reader_settings:flipNilOrTrue(Dashboard.TAP_ART_SETTING_KEY)
        end,
    }
end

local function showIntervalDialog(touchmenu_instance)
    local min_value = CpuInfo.MIN_SAMPLE_INTERVAL
    local max_value = CpuInfo.MAX_SAMPLE_INTERVAL
    local dialog

    local function applyValue()
        local value = tonumber(dialog:getInputText())

        if not value or value < min_value or value > max_value then
            UIManager:show(InfoMessage:new{
                text = string.format(
                    _("Enter a number between %d and %d"),
                    min_value,
                    max_value
                ),
                timeout = 3,
            })

            return
        end

        G_reader_settings:saveSetting(
            CpuInfo.INTERVAL_SETTING_KEY,
            math.floor(value)
        )

        CpuInfo.applyInterval()
        UIManager:close(dialog)

        if touchmenu_instance then
            touchmenu_instance:updateItems()
        end
    end

    dialog = InputDialog:new{
        title = _("CPU update interval (seconds)"),
        input = tostring(CpuInfo.getSampleInterval()),
        input_type = "number",

        buttons = {
            {
                {
                    text = _("Cancel"),
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text = _("Set"),
                    is_enter_default = true,
                    callback = applyValue,
                },
            },
        },
    }

    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

local function buildIntervalItem()
    return {
        keep_menu_open = true,

        text_func = function()
            return _("CPU_INTERVAL")
                .. " (" .. CpuInfo.getSampleInterval() .. " s)"
        end,

        callback = showIntervalDialog,
    }
end

local function buildResetItem()
    return {
        keep_menu_open = true,

        text_func = function()
            return _("RESET_CPU_INTERVAL")
                .. " (" .. CpuInfo.DEFAULT_SAMPLE_INTERVAL .. " s)"
        end,

        enabled_func = function()
            return CpuInfo.getSampleInterval()
                ~= CpuInfo.DEFAULT_SAMPLE_INTERVAL
        end,

        callback = function(touchmenu_instance)
            G_reader_settings:saveSetting(
                CpuInfo.INTERVAL_SETTING_KEY,
                CpuInfo.DEFAULT_SAMPLE_INTERVAL
            )

            CpuInfo.applyInterval()

            if touchmenu_instance then
                touchmenu_instance:updateItems()
            end
        end,
    }
end

function Menu.build(autostart_key)
    return {
        text = _("Kofetch"),
        sorting_hint = "filemanager_settings",

        sub_item_table = {
            buildEnableItem(autostart_key),
            buildMenuColorItem(),
            buildTapArtItem(),
            buildIntervalItem(),
            buildResetItem(),
        },
    }
end

return Menu